package dev.startto.app_agendamento

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
