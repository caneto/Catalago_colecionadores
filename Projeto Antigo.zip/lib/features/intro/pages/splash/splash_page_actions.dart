abstract class SplashPageActions {
  void navToOnboarding();
  void navToMaintenance();
  void navToHome();
  void navToAuth();
  void navForceUpdate();
  void navToPath(String path);
}