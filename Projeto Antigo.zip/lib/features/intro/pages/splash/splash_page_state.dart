part of 'splash_page_cubit.dart';

class SplashPageState extends Equatable {
  const SplashPageState();

  @override
  List<Object> get props => [];
}
