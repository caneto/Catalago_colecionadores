abstract interface class OnboardingPageActions {
  Future<void> showDeniedForeverDialog();
  void navToAuth();
}