enum ValidateTokenFailed {
  invalidToken,
  unknownError
}