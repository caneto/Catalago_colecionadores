enum SignUpFailed {
  unknownError
}