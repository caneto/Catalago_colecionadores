enum LoginFailed {
  invalidCredentials,
  offline,
  unknownError
}