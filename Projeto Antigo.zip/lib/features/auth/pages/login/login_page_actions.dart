abstract interface class LoginPageActions {
  void navToHome();
}