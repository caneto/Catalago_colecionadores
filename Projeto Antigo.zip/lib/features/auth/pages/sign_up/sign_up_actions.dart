abstract interface class SignUpActions {
  void navToHome();
}