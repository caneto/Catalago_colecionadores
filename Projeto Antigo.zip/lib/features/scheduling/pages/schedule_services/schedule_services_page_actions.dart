abstract class ScheduleServicesPageActions {
  void navToScheduling(String id);
}