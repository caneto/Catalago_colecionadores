# Catalago de Colecionadores

Projeto de Criação de um App - A principio para Android, para cadastrar e controlar coleções inicialmente de 'Carrinhos', futuramente de outros itens.
